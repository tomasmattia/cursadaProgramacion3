<?php
    use \Psr\Http\Message\ServerRequestInterface as Request;
    use \Psr\Http\Message\ResponseInterface as Response;

    require_once './vendor/autoload.php';
//    require_once '/clases/AccesoDatos.php';
//    require_once '/clases/cd.php';

    $config['displayErrorDetails'] = true;
    $config['addContentLengthHeader'] = false;

    /*
    ¡La primera línea es la más importante! A su vez en el modo de 
    desarrollo para obtener información sobre los errores
    (sin él, Slim por lo menos registrar los errores por lo que si está utilizando
    el construido en PHP webserver, entonces usted verá en la salida de la consola 
    que es útil).

    La segunda línea permite al servidor web establecer el encabezado Content-Length, 
    lo que hace que Slim se comporte de manera más predecible.
    */

    //*********************************************************************************************//
    //INICIALIZO EL APIREST
    //*********************************************************************************************//
    $app = new \Slim\App(["settings" => $config]);

    $app->get('[/]', function (Request $request, Response $response) {    
        $response->getBody()->write("GET => Bienvenido!!! a SlimFramework");
        return $response;
    
    });

    $app->get('/rutas/{param}[/{param2}]', function (Request $request, Response $response, array $args ) {   
        $param=$args['param']; 
        if(isset($args['param2']))
        {
            $param2=$args['param2'];
            $response->getBody()->write("Rutas por GET con param = $param y $param2");
            return $response;
        }    
        else
        {
            $response->getBody()->write("Rutas por GET con param = $param");
            return $response;
        }
    });

    $app->group('/grupo/', function () { 
        $this->get('any', function (Request $request, Response $response) 
        {
            $response->getBody()->write("Todos con param = ".$request->getMethod());
            return $response;
        });
        
        $this->post('any', function (Request $request, Response $response) 
        {
            $response->getBody()->write("POST => Todos con param = ".$request->getMethod());
            return $response;
        });

        $this->put('any', function (Request $request, Response $response) 
        {
            $response->getBody()->write("POST => Todos con param = ".$request->getMethod());
            return $response;
        });

        $this->delete('any', function (Request $request, Response $response) 
        {
            $response->getBody()->write("POST => Todos con param = ".$request->getMethod());
            return $response;
        });
    });
    
    
    $app->any('/todos/', function (Request $request, Response $response) {   
        $response->getBody()->write("Todos con param = ".$request->getMethod());
        return $response;
    });

    $app->post('[/]', function (Request $request, Response $response) {   
        $response->getBody()->write("POST => Bienvenido!!! a SlimFramework");
        return $response;
    
    });

    $app->put('[/]', function (Request $request, Response $response) {    
        $response->getBody()->write("PUT => Bienvenido!!! a SlimFramework");
        return $response;
    
    });

    $app->delete('[/]', function (Request $request, Response $response) {    
        $response->getBody()->write("DELETE => Bienvenido!!! a SlimFramework");
        return $response;
    
    });

    $app->run();

?>