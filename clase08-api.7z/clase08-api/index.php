<?php
    use \Psr\Http\Message\ServerRequestInterface as Request;
    use \Psr\Http\Message\ResponseInterface as Response;

    require_once './verificarUsuario.php';
    require_once './vendor/autoload.php';
//  require_once '/clases/AccesoDatos.php';
//  require_once '/clases/cd.php';

    $config['displayErrorDetails'] = true;
    $config['addContentLengthHeader'] = false;

    $app = new \Slim\App(["settings" => $config]);

    $app->post('/', function (Request $request, Response $response) {    
        $response->getBody()->write("Buenas Tardes <br>");
        return $response;
    });

    $app->add(\Verificadora::class.':VerificarUser');
    $app->run();
?>