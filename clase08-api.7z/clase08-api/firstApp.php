<?php
    use \Psr\Http\Message\ServerRequestInterface as Request;
    use \Psr\Http\Message\ResponseInterface as Response;

    require_once './vendor/autoload.php';
//  require_once '/clases/AccesoDatos.php';
//  require_once '/clases/cd.php';

    $config['displayErrorDetails'] = true;
    $config['addContentLengthHeader'] = false;

    $app = new \Slim\App(["settings" => $config]);

    $app->get('/param/', function (Request $request, Response $response) {    
        $response->getBody()->write("GET => Bienvenido!!! a SlimFramework <br>");
        return $response;
    })->add(function($request,$response,$next)
    {
        $response->getBody()->write('BEFORE RUTE <br>');
        $response = $next($request, $response);
        $response->getBody()->write('AFTER RUTE <br>');

        return $response;
    });

    $app->get('/usuarios', function (Request $request, Response $response) {    
        $response->getBody()->write("GET => Bienvenido!!! a SlimFramework <br>");
        return $response;
    })->add(\Verificadora::class , ':VerificarUsuario')
    {
        
    });

    $app->get('[/]', function (Request $request, Response $response) {    
        $response->getBody()->write("GET => Bienvenido!!! a SlimFramework <br>");
        return $response;
    });

    $app->post('[/]', function (Request $request, Response $response) {    
        $response->getBody()->write("GET => Bienvenido!!! a SlimFramework <br>");
        return $response;
    });

    $app->add(function($request,$response,$next)
    {
        $response->getBody()->write('BEFORE <br>');
        $response = $next($request, $response);
        $response->getBody()->write('AFTER <br>');

        return $response;
    });

    $app->group('/credenciales', function ($request) { 
        $this->get('[/]', function (Request $request, Response $response) 
        {
            $response->getBody()->write("Hola mortal, no podes ver esto sry  <br>");
            return $response;
        })->add(function($request,$response,$next)
        {
            $response->getBody()->write('BEFORE METHOD GROUP <br>');
            $response = $next($request, $response);
            $response->getBody()->write('AFTER METHOD GROUP <br>');
    
            return $response;
        });
        
        $this->post('[/]', function (Request $request, Response $response) 
        {
            $response->getBody()->write("Esto es el post <br>");
            return $response;
        });
    })->add(function($request,$response,$next)
    {
        if($request->isGet()){
            $metodo= "GET";
        }
        else
        {
            $metodo= "POST";
        }
        $response->getBody()->write('BEFORE GROUP y el metodo es '.$metodo.' <br> ');

        $parametros=$request->getParsedBody();
        if(isset($parametros['nombre']) && isset($parametros['perfil']))
        {
            if($parametros['perfil'] == "admin")
            {
                $response->getBody()->write("Hola ".$parametros['nombre']." no destruyas el codigo pls<br>");
            }
        }   
        if($metodo=="POST" && $parametros['perfil'] == "admin")
        {
            $response = $next($request, $response);
            $response->getBody()->write('AFTER GROUP <br>');
            return $response;
        }
        if($metodo=="GET")
        {
            $response = $next($request, $response);
            $response->getBody()->write('AFTER GROUP <br>');
            return $response;
        }
        $response->getBody()->write('Holo mortal <br>');        
        $response->getBody()->write('AFTER GROUP <br>');
        return $response;
    });


    $app->run();
?>