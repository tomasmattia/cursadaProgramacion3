function MandarJSON(){

    let objeto={
        nombre:$('#username').val(),
        perfil:$('#password').val()
    };
    $.ajax({
        type:"POST",
        url:"http://localhost:8080/clase08-api/verificarUsuario",
        data:objeto,
        datatype:"JSON",
        async:true
    })
    .done((objPersona)=>{
        $("#divMostrar").html(objPersona);
    })
}