<?php
    class Verificadora
    {
        public function VerificarUser($require,$response,$next)
        {
            $parametros=$require->getParsedBody();
            try
            {
                $usuario='root';
                $clave='';
                $objetoPDO = new PDO('mysql:host=localhost;dbname=usuarios;charset=utf8', $usuario, $clave);
                $sql=$objetoPDO->prepare('SELECT * FROM `lista` WHERE `username`= :username AND `password`= :password');
                $sql->bindValue(':username', $parametros['username']);
                $sql->bindValue(':password', $parametros['password']);
                $sql->execute();
                if($sql->rowCount() === 1)
                {
                    $response->getBody()->write('Bienvenido '.$parametros['username'].'<br>');
                    $response = $next($require, $response);
                    return $response;
                }
                $response->getBody()->write('Error no se encuentra el perfil');
            }
            catch(PDOException $e) 
            {
                echo "Error!\n" . $e->getMessage();
            }
            return $response;
        }
    }

?>