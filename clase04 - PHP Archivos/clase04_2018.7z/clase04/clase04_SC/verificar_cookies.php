<?php

var_dump($_COOKIE);

?>
<a href="Cookies/verificar_cookies.php" >Volver</a>
<br/>
<a href="./index.html" >Volver al Inicio</a>