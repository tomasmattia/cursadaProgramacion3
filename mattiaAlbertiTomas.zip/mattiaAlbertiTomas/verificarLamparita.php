<?php
    require_once "./clases/lamparita.php";

    $banderaTipo=0;
    $banderaColor=0;
    $tipo = $_GET['tipo'];
    $color = $_GET['color'];
    $arrayLamparitas = Lamparita::TraerTodasLamparas();
    foreach($arrayLamparitas as $lamparita)
    {
        if($lamparita->GetTipo()==$tipo)
        {
            $banderaTipo=1;
        }
        if($lamparita->GetColor()==$color)
        {
            $banderaColor=1;
        }
        if($lamparita->GetTipo()==$tipo && $lamparita->GetColor()==$color)
        {
            echo $lamparita->ToString();
            echo $lamparita->PrecioMasIva();
            exit;
        }
    }

    if($banderaTipo!=1 && $banderaColor!=1)
    {
        echo "No hay lamparas con ese tipo ni color";
    }
    else
    {
        if($banderaTipo!=1 && $banderaColor!=0)
        {
            echo "No hay lamparas con ese tipo";
        }
        elseif($banderaColor!=1 && $banderaTipo!=0)
        {
            echo "No hay lamparas con ese color";
        }
    }
?>