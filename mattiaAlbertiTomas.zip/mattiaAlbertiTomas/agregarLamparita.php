<?php
    require_once "./clases/lamparita.php";
    $tipo = $_POST['tipo'];
    $precio = $_POST['precio'];
    $color = $_POST['color'];
    $foto = $_FILES['foto']; 

    $rutaFoto="./lamparitas/imagenes/".$tipo.'.'.$color.'.'.date("H").date("i").date("s").".jpg";

    $lamparita = new Lamparita($tipo,$precio,$color,$rutaFoto);

    

    $lamparita->Agregar();

    move_uploaded_file($_FILES['foto']['tmp_name'],$rutaFoto);      
    echo "Carga Exitosa";
    header('Location: ./listado.php');

?>