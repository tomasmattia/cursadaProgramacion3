<?php
    require_once "./clases/lamparita.php";
    $arrayLamparitas = Lamparita::TraerTodas();
    foreach($arrayLamparitas as $lampara)
    {
        $objJson = json_encode($lampara);
        var_dump($objJson);
        $ruta="./archivos/listado.txt";
        $archivoDeLamparitas=fopen($ruta,"a");
        $auxEscritura = "";
        $auxEscritura=$auxEscritura.$objJson."\r\n";
        if(!(fwrite($archivoDeLamparitas, $auxEscritura)))
        {
            fclose($archivoDeLamparitas);
        }
        fclose($archivoDeLamparitas);        
    }
    

?>