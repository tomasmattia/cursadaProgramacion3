<?php
    require_once "./clases/lamparita.php";
    $tipo = $_POST['tipo'];
    $precio = $_POST['precio'];
    $color = $_POST['color'];
    $foto = $_FILES['foto'];

    if(isset($_POST['precio']) && isset($_POST['color']) && isset($_POST['tipo']) && isset($_FILES['foto']))
    {
        $lamparita = new Lamparita($tipo);
        $arrayDeLamparitas= Lamparita::TraerTodasLamparas();
        foreach($arrayDeLamparitas as $lamparita)
        {
            if($lamparita->GetTipo()==$tipo)
            {
                $lamparita->Modificar($tipo,$precio,$color,$foto['name']);
                move_uploaded_file($_FILES['foto']['tmp_name'],'./lamparitas/lamparitasModificadas/'.$tipo.'.'.$color.date("H").date("i").date("s").".jpg");
                unlink($lamparita->GetPathFoto());
                exit;
            }
        }
    }

?>