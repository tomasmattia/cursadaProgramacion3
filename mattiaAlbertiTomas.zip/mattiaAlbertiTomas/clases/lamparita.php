<?php
    require_once "iVendible.php";
    class Lamparita implements IVendible
    {
        private $tipo;
        private $precio;
        private $color;
        private $pathFoto;

        public function __construct($tipo="",$precio="",$color="",$pathFoto="")
        {
            $this->tipo=$tipo;
            $this->precio=$precio;
            $this->color=$color;
            $this->pathFoto=$pathFoto;
        }
        public function GetTipo()
        {
            return $this->tipo;
        }
        public function GetPrecio()
        {
            return $this->precio;
        }
        public function GetColor()
        {
            return $this->color;
        }
        public function GetPathFoto()
        {
            return $this->pathFoto;
        }
        public function SetTipo($tipo)
        {
            $this->tipo=$tipo;
        }
        public function SetPrecio($precio)
        {
            $this->precio=$precio;
        }
        public function SetColor($color)
        {
            $this->color=$color;
        }
        public function SetPathFoto($pathFoto)
        {
            $this->_pathFoto=$pathFoto;
        }
        
        public function PrecioMasIva()
        {
            return $this->precio * 1.21;
        }

        public function ToString()
        {
            return $this->tipo."-".$this->precio."-".$this->color."-".$this->pathFoto;
        }

        public function Agregar()
        {
            try
            {
                echo "Entra agregar";
                $usuario='root';
                $clave='';
                $objetoPDO = new PDO('mysql:host=localhost;dbname=lamparitas_bd;charset=utf8', $usuario, $clave);
                $sql=$objetoPDO->prepare('INSERT INTO `lamparitas`(`tipo`, `color`, `precio`, `path`) VALUES (:tipo, :color, :precio, :path)');

                $sql->execute(array(
                    'tipo' => $this->tipo,
                    'color' => $this->color,
                    'precio' => $this->precio,
                    'path' => $this->pathFoto
                ));

            }
            catch(PDOException $e) 
            {
                echo "Error!\n" . $e->getMessage();
            }
        }

        public static function TraerTodas()
        {
            $arrayDeLamparitas=array();
            try
            {
                $usuario='root';
                $clave='';
                $objetoPDO = new PDO('mysql:host=localhost;dbname=lamparitas_bd;charset=utf8', $usuario, $clave);
                $sql=$objetoPDO->prepare('SELECT `tipo`, `color`, `precio`, `path` FROM `lamparitas`');
                $sql->execute();
                while($result = $sql->fetchObject())
                {
                    array_push($arrayDeLamparitas,$result);
                }
            }
            catch(PDOException $e) 
            {
                echo "Error!\n" . $e->getMessage();
            }
            return $arrayDeLamparitas;
        }

        public static function TraerTodasLamparas()
        {
            $arrayDeLamparitas=array();
            try
            {
                $usuario='root';
                $clave='';
                $objetoPDO = new PDO('mysql:host=localhost;dbname=lamparitas_bd;charset=utf8', $usuario, $clave);
                $sql=$objetoPDO->prepare('SELECT `tipo`, `color`, `precio`, `path` FROM `lamparitas`');
                $sql->execute();
                while($result = $sql->fetchObject())
                {
                    $lamparita = new Lamparita($result->tipo,$result->precio,$result->color,$result->path);
                    array_push($arrayDeLamparitas,$lamparita);
                }
            }
            catch(PDOException $e) 
            {
                echo "Error!\n" . $e->getMessage();
            }
            return $arrayDeLamparitas;
        }


        public function Borrar()
        {
            try
            {
                $usuario='root';
                $clave='';
                $objetoPDO = new PDO('mysql:host=localhost;dbname=lamparitas_bd;charset=utf8', $usuario, $clave);
                $sql=$objetoPDO->prepare('DELETE FROM `lamparitas` WHERE `tipo`= :tipo');
                $arrayDeLamparitas= Lamparita::TraerTodasLamparas();
                foreach($arrayDeLamparitas as $lamparita)
                {
                    if($lamparita->tipo==$this->tipo)
                    {
                        $sql->execute(array(
                            'tipo' => $lamparita->tipo
                        ));
                        $rutaVieja=$lamparita->pathFoto;
                        break;
                    }
                }
                $rutaFoto="./lamparitas/lamparitasBorradas/".$this->GetTipo().'.borrado.'.date("H").date("i").date("s").".jpg";
                
                rename($rutaVieja,$rutaFoto);
            }
            catch(PDOException $e) 
            {
                echo "Error!\n" . $e->getMessage();
            }
        }

        public static function Modificar($tipo,$precio,$color,$foto)
        {
            try
            {
                $usuario='root';
                $clave='';
                $objetoPDO = new PDO('mysql:host=localhost;dbname=lamparitas_bd;charset=utf8', $usuario, $clave);
                $sql=$objetoPDO->prepare('UPDATE `lamparitas` SET `tipo`= :tipo,`precio`= :precio,`color`= :color,`path`= :path  WHERE `tipo`= :tipoOld');
                $arrayDeLamparitas= Lamparita::TraerTodasLamparas();
                foreach($arrayDeLamparitas as $lamparita)
                {
                    if($lamparita->tipo==$tipo)
                    {
                        $sql->execute(array(
                            'tipo' => $tipo,
                            'precio' => $precio,
                            'color' => $color,
                            'path' => $foto,
                            'tipoOld' => $tipo
                        ));
                        $rutaVieja=$lamparita->pathFoto;
                        break;
                    }
                }                
            }
            catch(PDOException $e) 
            {
                echo "Error!\n" . $e->getMessage();
            }
        }
    }
?>