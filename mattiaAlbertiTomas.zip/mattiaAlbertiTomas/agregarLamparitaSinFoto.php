<?php
    require_once "./clases/lamparita.php";
    $tipo = $_POST['tipo'];
    $precio = $_POST['precio'];
    $color = $_POST['color'];

    $lamparita = new Lamparita($tipo,$precio,$color);

    $lamparita->Agregar();

    $ruta="./archivos/lamparitas_sin_foto.txt";
    $archivoDeLamparitas=fopen($ruta,"a");
    $auxEscritura = "";
    $auxEscritura=$auxEscritura.$lamparita->GetTipo()."-".$lamparita->GetPrecio()."-".$lamparita->GetColor()."-".date("Y").date("m").date("d").date("H").date("i")."\r\n";
    if(!(fwrite($archivoDeLamparitas, $auxEscritura)))
    {
        fclose($archivoDeLamparitas);            
        echo "Error en la carga";
    }
    fclose($archivoDeLamparitas);        
    echo "Carga Exitosa";
?>