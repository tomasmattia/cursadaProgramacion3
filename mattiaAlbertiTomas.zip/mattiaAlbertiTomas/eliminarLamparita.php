<?php
    require_once "./clases/lamparita.php";

    if(isset($_GET['tipo']))
    {
        $existe=0;
        $tipoGet=$_GET['tipo'];
        $arrayDeLamparitas= Lamparita::TraerTodasLamparas();
        foreach($arrayDeLamparitas as $lamparita)
        {
            if($lamparita->GetTipo()==$tipoGet)
            {
                echo "Existe la lamparita";
                $existe=1;
                exit;
            }
        }
        if($existe==0)
        {
            echo "No existe la lamparita";
        }
    }
    else
    {
        if(isset($_POST['tipo']))
        {
            if(isset($_POST['accion']))
            {
                $tipo = $_POST['tipo'];
                $accion = $_POST['accion'];
                $lamparita = new Lamparita($tipo);
                if($accion=="borrar")
                {
                    $arrayDeLamparitas= Lamparita::TraerTodasLamparas();
                    foreach($arrayDeLamparitas as $lamparita)
                    {
                        if($lamparita->GetTipo()==$tipo)
                        {
                            $lamparita->Borrar();
                            exit;
                        }
                    }
                }
            }
        }
    }


?>