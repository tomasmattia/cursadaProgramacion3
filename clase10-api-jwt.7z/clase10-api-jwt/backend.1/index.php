<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;
use \Firebase\JWT\JWT as JWT;

require 'vendor/autoload.php';

$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

$app = new \Slim\App(["settings" => $config]);

$app->get('/hello/{name}', function (Request $request, Response $response, array $args) {
    $name = $args['name'];
    $response->getBody()->write("Hello, $name");

    return $response;
});

$app->group('/test', function (){
    $this->post('[/]', function (Request $request, Response $response) {   
        $params=$request->getParsedBody();
        $key = "example_key";
        $payload=array(
            "user"=> $params['user'],
            "pass"=> $params['pass']
        );
        $jwt = JWT::encode($payload, $key);
        return $response->withJson($jwt,200);
    });
    $this->get('/{token}', function (Request $request, Response $response, array $args){
        $elToken=$args['token'];
        var_dump($elToken);
        if(empty($elToken)|| $elToken === "")
        {
            echo "el token esta vacio";
        }
        try
        {
            $jwtDecode = JWT::decode($elToken,'example_key',array('HS256'));
            return $response->withJson($jwtDecode,200);
        }
        catch(Exception $e)
        {
            $response->getBody()->write("JWT ERROR : ".$e->getMessage());
            throw $e;
        }
    });
});

$app->run();

?>