<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;
use \Firebase\JWT\JWT as JWT;

require 'vendor/autoload.php';
require 'verificadora.php';

$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

$app = new \Slim\App(["settings" => $config]);


// $app->get('/', function (Request $request, Response $response) {    
//     $response->getBody()->write("Buenas Tardes este es el metodo get <br>");
//     return $response;
// })->add(\Verificadora::class.'::TraerLosCds');

// $app->post('/', function (Request $request, Response $response) {    
//     $response->getBody()->write("Buenas Tardes este es el metodo post <br>");
//     return $response;
// })->add(\Verificadora::class.':AgregarCd');

// $app->put('/', function (Request $request, Response $response) {    
//     $response->getBody()->write("Buenas Tardes este es el metodo put <br>");
//     return $response;
// });

// $app->delete('/', function (Request $request, Response $response) {    
//     $response->getBody()->write("Buenas Tardes este es el metodo delete <br>");
//     return $response;
// })->add(\Verificadora::class.':EliminarCd')->add(\Verificadora::class.':EsSuperAdmin');

$app->post('/add', function (Request $request, Response $response, $next) {   
    $params=$request->getParsedBody();
    $elToken= $params['token'];
    var_dump($elToken);
    if(empty($elToken)|| $elToken === "")
    {
        echo "el token esta vacio";
    }
    try
    {
        $jwtDecode = JWT::decode($elToken,'example_key',array('HS256'));
        Verificadora::AgregarCd($request,$response,$next);
        return $response;
    }
    catch(Exception $e)
    {
        $response->getBody()->write("JWT ERROR : ".$e->getMessage());
        throw $e;
    }
});

$app->get('/',function(Request $request, Response $response){
    $elToken= $request->getHeader('token');
    var_dump($elToken[0]);
    if(empty($elToken[0])|| $elToken[0] === "")
    {
        echo "el token esta vacio";
    }
    try
    {
        $jwtDecode = JWT::decode($elToken[0],'example_key',array('HS256'));
        Verificadora::TraerLosCds($request,$response);
        return $response;
    }
    catch(Exception $e)
    {
        $response->getBody()->write("JWT ERROR : ".$e->getMessage());
        throw $e;
    }
});

// $app->add(\Verificadora::class.':VerificarUsuario');

$app->run();